
use anchor_lang::prelude::*;

// ID del programa: coloca aquí el Program ID de Solana Playground.
declare_id!("Hv2LRM6n6D8dw9xM4mUvynzCSuSCnNPbJvkDLeiqadNP");

#[program]
pub mod registro_ventas {
    use super::*;

    //////////////////////////// Instruccion: Crear Registro ////////////////////////////

    /*
    Permite crear una PDA donde se almacenaran todos los clientes
    del negocio y sus respectivos historiales de ventas.

    La PDA depende de:
        * Wallet address (owner)
        * Program ID
        * Semilla representativa del proyecto
    */

    pub fn crear_registro(
        context: Context<NuevoRegistro>,
        nombre_negocio: String,
    ) -> Result<()> {

        // Validamos la longitud del nombre del negocio.
        require!(
            nombre_negocio.len() <= 30,
            Errores::NombreMuyLargo
        );

        let owner_id = context.accounts.owner.key();

        // El negocio inicia sin clientes.
        let clientes = Vec::new();

        // Contador incremental de clientes.
        let id_counter: u16 = 0;

        // Guardamos el registro dentro de la PDA.
        context.accounts.registro.set_inner(Registro {
            owner: owner_id,
            nombre_negocio: nombre_negocio.clone(),
            clientes,
            id_counter,
        });

        msg!(
            "Registro: {} creado exitosamente!",
            nombre_negocio
        );

        Ok(())
    }

    //////////////////////////// Instruccion: Registrar Venta ////////////////////////////

    /*
    Registra una venta con dos comportamientos:

        * id_cliente == 0 -> crea un cliente nuevo.
        * id_cliente != 0 -> agrega una venta a un cliente existente.

    Todo se almacena dentro de la misma cuenta Registro.
    */

    pub fn registrar_venta(
        context: Context<ModificarVenta>,
        id_cliente: u16,
        sku: String,
        descripcion: String,
        monto: u32,
    ) -> Result<()> {

        require!(
            context.accounts.registro.owner == context.accounts.owner.key(),
            Errores::NoOwner
        );

        // Validamos las longitudes permitidas.
        require!(sku.len() <= 5, Errores::SkuMuyLargo);
        require!(
            descripcion.len() <= 50,
            Errores::DescripcionMuyLarga
        );

        let registro = &mut context.accounts.registro;

        let venta = Venta {
            sku,
            descripcion,
            monto,
        };

        if id_cliente == 0 {

            // ---- Caso A: cliente nuevo ----

            require!(
                registro.clientes.len() < 10,
                Errores::MaxClientes
            );

            registro.id_counter = registro
                .id_counter
                .checked_add(1)
                .ok_or(Errores::ContadorAgotado)?;

            let id = registro.id_counter;

            msg!(
                "El ID de cliente es: {}, articulo: {}, total: {}",
                id,
                venta.sku,
                venta.monto
            );

            registro.clientes.push(Cliente {
                id_cliente: id,
                compras: 1,
                historial: vec![venta],
            });

            return Ok(());

        } else {

            // ---- Caso B: cliente existente ----

            let cliente = registro.clientes
                .iter_mut()
                .find(|c| c.id_cliente == id_cliente);

            if let Some(cliente) = cliente {

                require!(
                    cliente.historial.len() < 10,
                    Errores::MaxVentas
                );

                msg!(
                    "Compro el articulo {} registrada con un costo total de {}",
                    venta.sku,
                    venta.monto
                );

                cliente.historial.push(venta);
                cliente.compras += 1;

                return Ok(());
            }
        }

        // El cliente no existe.
        msg!("El ID del cliente: {} no fue encontrado D:", id_cliente);

        Err(Errores::NoUser.into())
    }

    //////////////////////////// Instruccion: Hacer Devolucion ////////////////////////////

    /*
    Elimina una venta del historial mediante el SKU.

    Error si el cliente no existe, su historial esta vacio
    o el SKU no aparece.
    */

    pub fn hacer_devolucion(
        context: Context<ModificarVenta>,
        id_cliente: u16,
        sku: String,
    ) -> Result<()> {

        require!(
            context.accounts.registro.owner == context.accounts.owner.key(),
            Errores::NoOwner
        );

        let clientes = &mut context.accounts.registro.clientes;

        let cliente = clientes
            .iter_mut()
            .find(|c| c.id_cliente == id_cliente);

        if let Some(cliente) = cliente {

            require!(
                !cliente.historial.is_empty(),
                Errores::SinCompras
            );

            let posicion = cliente.historial
                .iter()
                .position(|v| v.sku == sku);

            if let Some(posicion) = posicion {

                cliente.historial.remove(posicion);
                cliente.compras -= 1;

                msg!("Devolucion  se realizo exitosamente");

                return Ok(());
            }

            return Err(Errores::NoSKU.into());
        }

        Err(Errores::NoUser.into())
    }

    //////////////////////////// Instruccion: Cambiar Monto ////////////////////////////

    /*
    Corrige el importe de una venta localizandola por cliente y SKU.
    */

    pub fn cambiar_monto(
        context: Context<ModificarVenta>,
        id_cliente: u16,
        sku: String,
        nuevo_monto: u32,
    ) -> Result<()> {

        require!(
            context.accounts.registro.owner == context.accounts.owner.key(),
            Errores::NoOwner
        );

        let clientes = &mut context.accounts.registro.clientes;

        let cliente = clientes
            .iter_mut()
            .find(|c| c.id_cliente == id_cliente);

        if let Some(cliente) = cliente {

            let venta = cliente.historial
                .iter_mut()
                .find(|v| v.sku == sku);

            if let Some(venta) = venta {

                let viejo_monto = venta.monto;
                venta.monto = nuevo_monto;

                msg!(
                    "El monto se actualizado exitosamente, anteriormente era de {} y paso a {}.",
                    viejo_monto,
                    nuevo_monto
                ); 

                return Ok(());
            }

            return Err(Errores::NoSKU.into());
        }

        Err(Errores::NoUser.into())
    }

    //////////////////////////// Instruccion: Cantidad de Compras ////////////////////////////

    /*
    Muestra en los logs la cantidad de compras y el historial.

    La instruccion no devuelve directamente los datos al frontend.
    Para leerlos se utiliza fetch sobre la cuenta Registro.
    */

    pub fn cantidad_compras(
        context: Context<ModificarVenta>,
        id_cliente: u16,
    ) -> Result<()> {

        require!(
            context.accounts.registro.owner == context.accounts.owner.key(),
            Errores::NoOwner
        );

        let clientes = &context.accounts.registro.clientes;

        let cliente = clientes
            .iter()
            .find(|c| c.id_cliente == id_cliente);

        if let Some(cliente) = cliente {

            msg!(
                "El cliente tiene un total de compras de {}:",
                cliente.compras
            );

            msg!(
                "Lista de productos comprados: {:#?}",
                cliente.historial
            );

            return Ok(());
        }

        Err(Errores::NoUser.into())
    }
}

//////////////////////////// Codigos de error ////////////////////////////

#[error_code]
pub enum Errores {

    #[msg("Error, no eres el owner del registro")]
    NoOwner,

    #[msg("Error, usuario no existe")]
    NoUser,

    #[msg("Error, SKU no encontrado")]
    NoSKU,

    #[msg("Error, no hay compras en el historial")]
    SinCompras,

    #[msg("Error, se alcanzo el limite de 10 clientes")]
    MaxClientes,

    #[msg("Error, se alcanzo el limite de 10 ventas por cliente")]
    MaxVentas,

    #[msg("Error, el nombre del negocio supera los 30 bytes")]
    NombreMuyLargo,

    #[msg("Error, el SKU supera los 5 bytes")]
    SkuMuyLargo,

    #[msg("Error, la descripcion supera los 50 bytes")]
    DescripcionMuyLarga,

    #[msg("Error, el contador de clientes alcanzo su limite")]
    ContadorAgotado,
}

//////////////////////////// Structs ////////////////////////////

#[account]
#[derive(InitSpace)]
pub struct Registro {

    owner: Pubkey,

    #[max_len(30)]
    nombre_negocio: String,

    #[max_len(10)]
    clientes: Vec<Cliente>,

    id_counter: u16,
}

//////////////////////////// Struct Cliente ////////////////////////////

/*
Struct interno: no es una cuenta independiente.

Contiene el identificador, la cantidad de compras
y el historial de ventas del cliente.
*/

#[derive(
    AnchorSerialize,
    AnchorDeserialize,
    Clone,
    InitSpace,
    PartialEq,
    Debug
)]
pub struct Cliente {

    id_cliente: u16,

    compras: u16,

    #[max_len(10)]
    historial: Vec<Venta>,
}

//////////////////////////// Struct Venta ////////////////////////////

#[derive(
    AnchorSerialize,
    AnchorDeserialize,
    Clone,
    InitSpace,
    PartialEq,
    Debug
)]
pub struct Venta {

    #[max_len(5)]
    sku: String,

    #[max_len(50)]
    descripcion: String,

    monto: u32,
}

//////////////////////////// Contextos ////////////////////////////

#[derive(Accounts)]
pub struct NuevoRegistro<'info> {

    // El propietario firma y paga la creacion de la PDA.
    #[account(mut)]
    pub owner: Signer<'info>,

    #[account(
        init,
        payer = owner,
        space = Registro::INIT_SPACE + 8,
        seeds = [b"registro", owner.key().as_ref()],
        bump
    )]
    pub registro: Account<'info, Registro>,

    pub system_program: Program<'info, System>,
}

//////////////////////////// Contexto de modificacion ////////////////////////////

#[derive(Accounts)]
pub struct ModificarVenta<'info> {

    // Wallet que autoriza las operaciones.
    pub owner: Signer<'info>,

    // Verifica que se utilice la PDA correspondiente al propietario.
    #[account(
        mut,
        seeds = [b"registro", owner.key().as_ref()],
        bump
    )]
    pub registro: Account<'info, Registro>,
}
