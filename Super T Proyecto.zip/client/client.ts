import * as anchor from "@coral-xyz/anchor";
import * as web3 from "@solana/web3.js";

//////////////////// Imports ////////////////////

import { PublicKey } from "@solana/web3.js";

//////////////////// Constantes ////////////////////

const nombre_negocio = "Super T";
const owner = program.provider.publicKey;

// Limites establecidos en lib.rs.
const MAX_CLIENTES = 10;
const MAX_VENTAS = 10;

//////////////////// Obtener PDA ////////////////////

/*
La PDA se obtiene con las mismas semillas utilizadas
en el programa Rust:

    * b"registro"
    * Wallet address
    * Program ID
*/

function pdaRegistro() {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("registro"),
      owner.toBuffer(),
    ],
    program.programId
  );
}

//////////////////// Verificar conexion ////////////////////

async function verificarConexion() {
  console.log("Wallet:", owner.toString());

  const balance = await program.provider.connection.getBalance(owner);

  console.log(
    "Balance:",
    balance / web3.LAMPORTS_PER_SOL,
    "SOL"
  );
}

//////////////////// Crear Registro ////////////////////

/*
Crea la cuenta PDA del negocio.
Solo puede existir un registro por wallet
con las semillas utilizadas.
*/

async function crearRegistro(nombre = nombre_negocio) {

  if (!nombre || nombre.length > 30) {
    throw new Error("El nombre debe tener entre 1 a 30 caracteres.");
  }

  const [pda_registro] = pdaRegistro();

  const txHash = await program.methods
    .crearRegistro(nombre)
    .accounts({
      owner: owner,
      registro: pda_registro,
    })
    .rpc();

  console.log("Registro creado exitosamente");
  console.log("PDA:", pda_registro.toString());
  console.log("txHash:", txHash);

  return txHash;
}

//////////////////// Registrar Venta ////////////////////

/*
id_cliente == 0 -> crea cliente nuevo.
id_cliente != 0 -> agrega compra a cliente existente.
*/

async function registrarVenta(
  id_cliente: number,
  sku: string,
  descripcion: string,
  monto: number
) {

  if (!Number.isInteger(id_cliente) || id_cliente < 0 || id_cliente > 65535) {
    throw new Error("El ID del cliente novalido.");
  }

  if (!sku || sku.length > 5) {
    throw new Error("El SKU debe tener entre 1 a 5 caracteres.");
  }

  if (!descripcion || descripcion.length > 50) {
    throw new Error("La descripcion debe tener entre 1 a 50 caracteres.");
  }

  if (!Number.isInteger(monto) || monto < 0 || monto > 4294967295) {
    throw new Error("El monto debe de ser un numero entero u32.");
  }

  // Consultamos el registro antes de realizar la operacion.
  const registro = await verRegistro();

  if (id_cliente === 0) {

    if (registro.clientes.length >= MAX_CLIENTES) {
      throw new Error("El negocio ya cuenta con 10 clientes.");
    }

  } else {

    const cliente = registro.clientes.find(
      (c: any) => Number(c.idCliente) === id_cliente
    );

    if (!cliente) {
      throw new Error("El cliente no existe.");
    }

    if (cliente.historial.length >= MAX_VENTAS) {
      throw new Error("El cliente ya posee 10 ventas.");
    }
  }

  const [pda_registro] = pdaRegistro();

  const txHash = await program.methods
    .registrarVenta(id_cliente, sku, descripcion, monto)
    .accounts({
      owner: owner,
      registro: pda_registro,
    })
    .rpc();

  console.log("Venta registrada exitosamente");
  console.log("txHash:", txHash);

  return txHash;
}

//////////////////// Hacer Devolucion ////////////////////

/*
Elimina una venta del historial mediante:
    * ID del cliente.
    * SKU del producto.
*/

async function hacerDevolucion(
  id_cliente: number,
  sku: string
) {

  if (id_cliente <= 0 || !sku) {
    throw new Error("Debes indicar un cliente y un SKU.");
  }

  const [pda_registro] = pdaRegistro();

  const txHash = await program.methods
    .hacerDevolucion(id_cliente, sku)
    .accounts({
      owner: owner,
      registro: pda_registro,
    })
    .rpc();

  console.log("Devolucion realizada.");
  console.log("txHash:", txHash);

  return txHash;
}

//////////////////// Cambiar Monto ////////////////////

/*
Modifica el importe de una venta ya registrada.
*/

async function cambiarMonto(
  id_cliente: number,
  sku: string,
  nuevo_monto: number
) {

  if (!Number.isInteger(nuevo_monto) || nuevo_monto < 0 || import type { RegistroVentas } from "../target/types/registro_ventas";

// Configure the client to use the local cluster
anchor.setProvider(anchor.AnchorProvider.env());

const program = anchor.workspace.RegistroVentas as anchor.Program<RegistroVentas>;

nuevo_monto > 4294967295) {
    throw new Error("El nuevo monto debe ser un numero entero u32.");
  }

  const [pda_registro] = pdaRegistro();

  const txHash = await program.methods
    .cambiarMonto(id_cliente, sku, nuevo_monto)
    .accounts({
      owner: owner,
      registro: pda_registro,
    })
    .rpc();

  console.log("Monto actualizado.");
  console.log("txHash:", txHash);

  return txHash;
}

//////////////////// Cantidad de Compras ////////////////////

/*
Esta instruccion escribe el resultado en los logs.
No devuelve el historial al frontend.
*/

async function cantidadCompras(id_cliente: number) {

  const [pda_registro] = pdaRegistro();

  const txHash = await program.methods
    .cantidadCompras(id_cliente)
    .accounts({
      owner: owner,
      registro: pda_registro,
    })
    .rpc();

  console.log("Consulta ejecutada.");
  console.log("Para revisar los logs:");
  console.log("solana confirm -v", txHash);

  return txHash;
}

//////////////////// Ver Registro ////////////////////

/*
Obtiene toda la informacion de la cuenta PDA.
Un solo fetch permite consultar todos los clientes
y sus respectivos historiales.
*/

async function verRegistro() {

  const [pda_registro] = pdaRegistro();

  const registroAccount = await program.account.registro.fetch(
    pda_registro
  );

  return registroAccount;
}

//////////////////// Ver Clientes ////////////////////

async function verClientes() {

  try {

    const registroAccount = await verRegistro();

    console.log(
      "Negocio:",
      registroAccount.nombreNegocio
    );

    console.log(
      "Ultimo ID asignado:",
      registroAccount.idCounter
    );

    const clientes = registroAccount.clientes;

    if (!clientes || clientes.length === 0) {
      console.log("Registro vacio, aun no hay clientes.");
      return;
    }

    console.log("Cantidad de clientes:", clientes.length);

    for (let i = 0; i < clientes.length; i++) {

      const cliente = clientes[i];

      console.log(
        `\nCliente #${i + 1}
        ID: ${cliente.idCliente}
        Compras: ${cliente.compras}
        Ventas en historial: ${cliente.historial.length}`
      );

      for (let j = 0; j < cliente.historial.length; j++) {

        const venta = cliente.historial[j];

        console.log(
          `Venta #${j + 1}:
          SKU: ${venta.sku}
          Descripcion: ${venta.descripcion}
          Monto: $${venta.monto}`
        );
      }
    }

  } catch (error: any) {

    console.error("Error viendo clientes:", error);

    if (error.message) {
      console.error("Mensaje:", error.message);
    }

    if (error.logs) {
      console.error("Logs:", error.logs);
    }
  }
}

//////////////////// Ejemplo de ejecucion ////////////////////

/*
Ejecuta las funciones individualmente desde el cliente.

No descomentes todas al mismo tiempo, ya que algunas
dependen de que el registro y los clientes existan.

verificarConexion();

crearRegistro(nombre_negocio);

registrarVenta(0, "PAN", "Pan Bimbo", 48);
registrarVenta(1, "CAFE", "Cafe del Oxxo", 38);

cantidadCompras(1);

cambiarMonto(1, "PAN", 50);

hacerDevolucion(1, "CAFE");

verClientes();
*/
verificarConexion();
verClientes();