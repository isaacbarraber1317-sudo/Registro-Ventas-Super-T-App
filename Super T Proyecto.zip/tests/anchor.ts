import * as anchor from "@coral-xyz/anchor";
import assert from "assert";
import * as web3 from "@solana/web3.js";

/*
Pruebas automatizadas del programa registro_ventas.

IMPORTANTE:
Ejecutar inicialmente con una wallet que no tenga
un registro PDA creado para este programa.
*/

import { PublicKey } from "@solana/web3.js";
import type { RegistroVentas } from "../target/types/registro_ventas";

describe("Registro de ventas - Super T", () => {
  // Configure the client to use the local cluster
  anchor.setProvider(anchor.AnchorProvider.env());

  const program = anchor.workspace.RegistroVentas as anchor.Program<RegistroVentas>;
  

  const owner = program.provider.publicKey;

  const nombre_negocio = "Super T";

  const [pda_registro] = PublicKey.findProgramAddressSync(
    [
      Buffer.from("registro"),
      owner.toBuffer(),
    ],
    program.programId
  );

  it("Debe crear el registro del negocio", async () => {

    const existente = await program.account.registro.fetchNullable(
      pda_registro
    );

    if (existente === null) {

      const txHash = await program.methods
        .crearRegistro(nombre_negocio)
        .accounts({
          owner: owner,
          registro: pda_registro,
        })
        .rpc();

      await program.provider.connection.confirmTransaction(txHash);

      console.log("Registro creado:", txHash);

    } else {

      assert.equal(
        existente.nombreNegocio,
        nombre_negocio,
        "El registro existente pertenece a otro negocio."
      );

      console.log("El registro ya existe.");
    }

    const registro = await program.account.registro.fetch(
      pda_registro
    );

    assert.equal(
      registro.nombreNegocio,
      nombre_negocio
    );
  });

  it("Debe registrar un cliente y sus ventas", async () => {

    const registroInicial = await program.account.registro.fetch(
      pda_registro
    );

    // El programa crea un cliente al recibir id_cliente = 0.
    const tx1 = await program.methods
      .registrarVenta(
        0,
        "PAN",
        "Pan Bimbo",
        48
      )
      .accounts({
        owner: owner,
        registro: pda_registro,
      })
      .rpc();

    await program.provider.connection.confirmTransaction(tx1);

    const registroActual = await program.account.registro.fetch(
      pda_registro
    );

    // Obtenemos el ID asignado por el programa.
    const id_cliente = Number(registroActual.idCounter);

    assert.ok(
      id_cliente > Number(registroInicial.idCounter),
      "El ID del cliente no se incremento."
    );

    // Agregamos una segunda venta al mismo cliente.
    const tx2 = await program.methods
      .registrarVenta(
        id_cliente,
        "CAFE",
        "Nescafe",
        38
      )
      .accounts({
        owner: owner,
        registro: pda_registro,
      })
      .rpc();

    await program.provider.connection.confirmTransaction(tx2);

    const registroFinal = await program.account.registro.fetch(
      pda_registro
    );

    const cliente = registroFinal.clientes.find(
      (c: any) => Number(c.idCliente) === id_cliente
    );

    assert.ok(cliente, "No se encontro el cliente.");

    assert.equal(
      cliente.historial.length,
      2,
      "El historial no contiene las dos ventas."
    );

    assert.equal(
      Number(cliente.compras),
      2
    );

    console.log("Cliente y ventas registrados correctamente.");
  });

  it("Debe modificar el monto de una venta", async () => {

    const registro = await program.account.registro.fetch(
      pda_registro
    );

    const cliente = registro.clientes.find(
      (c: any) => c.historial.some(
        (v: any) => v.sku === "PAN"
      )
    );

    assert.ok(cliente, "No existe una venta con SKU PAN.");

    const id_cliente = Number(cliente.idCliente);

    const txHash = await program.methods
      .cambiarMonto(
        id_cliente,
        "PAN",
        50
      )
      .accounts({
        owner: owner,
        registro: pda_registro,
      })
      .rpc();

    await program.provider.connection.confirmTransaction(txHash);

    const registroActualizado = await program.account.registro.fetch(
      pda_registro
    );

    const clienteActualizado = registroActualizado.clientes.find(
      (c: any) => Number(c.idCliente) === id_cliente
    );

    const venta = clienteActualizado.historial.find(
      (v: any) => v.sku === "PAN"
    );

    assert.equal(
      Number(venta.monto),
      50,
      "El monto no fue actualizado."
    );

    console.log("Monto actualizado correctamente.");
  });

  it("Debe realizar una devolucion", async () => {

    const registro = await program.account.registro.fetch(
      pda_registro
    );

    const cliente = registro.clientes.find(
      (c: any) => c.historial.some(
        (v: any) => v.sku === "CAFE"
      )
    );

    assert.ok(cliente, "No existe una venta con SKU CAFE.");

    const id_cliente = Number(cliente.idCliente);

    const txHash = await program.methods
      .hacerDevolucion(
        id_cliente,
        "CAFE"
      )
      .accounts({
        owner: owner,
        registro: pda_registro,
      })
      .rpc();

    await program.provider.connection.confirmTransaction(txHash);

    const registroActualizado = await program.account.registro.fetch(
      pda_registro
    );

    const clienteActualizado = registroActualizado.clientes.find(
      (c: any) => Number(c.idCliente) === id_cliente
    );

    assert.equal(
      clienteActualizado.historial.length,
      1,
      "La devolucion no elimino la venta."
    );

    assert.equal(
      clienteActualizado.historial[0].sku,
      "PAN"
    );

    console.log("Devolucion verificada correctamente.");
  });

  it("Debe consultar la cantidad de compras", async () => {

    const registro = await program.account.registro.fetch(
      pda_registro
    );

    const cliente = registro.clientes.find(
      (c: any) => c.historial.some(
        (v: any) => v.sku === "PAN"
      )
    );

    assert.ok(cliente, "No se encontro el cliente.");

    const id_cliente = Number(cliente.idCliente);

    const txHash = await program.methods
      .cantidadCompras(id_cliente)
      .accounts({
        owner: owner,
        registro: pda_registro,
      })
      .rpc();

    const confirmacion = await program.provider.connection.confirmTransaction(
      txHash
    );

    assert.ok(
      confirmacion.value.err === null,
      "La consulta fallo."
    );

    console.log(
      "Consulta ejecutada. Transaccion:",
      txHash
    );

    console.log(
      "Compras registradas:",
      cliente.compras
    );
  });
});
